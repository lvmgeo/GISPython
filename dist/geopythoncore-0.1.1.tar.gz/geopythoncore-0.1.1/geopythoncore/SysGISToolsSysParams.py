# -*- coding: utf-8 -*-
"""
    Module for storing the scripting parameters
"""
Version = 'GISPython Core 10.3.1 - 1.33.0001' #Package version
